# 🧪 Prompt Testing Sandbox

A modern and interactive **Prompt Testing Sandbox** built with **HTML, CSS, and JavaScript** that allows users to design, test, compare, and analyze AI prompts in a clean and responsive interface. The application simulates AI responses, tracks prompt history, supports variable injection, and provides prompt testing metrics for experimentation and learning.

---

## 🚀 Live Demo

[prompttestingsandbox](https://prompttestingsandbox.netlify.app/)

---

## 🎥 Project Demo Video

https://github.com/user-attachments/assets/f01b878c-1535-442e-b869-96096ce5796e

---

## 📌 Features

- 🧪 Interactive Prompt Testing Environment
- 📝 Custom System Prompt Support
- 💬 User Prompt Input
- 🔄 Variable Injection using JSON
- 🤖 Multiple AI Model Selection
- 🌡️ Temperature Control Slider
- 🎯 Max Token Configuration
- 📊 Response Metrics Dashboard
- 📜 Prompt Testing History
- ⚡ Built-in Example Prompts
- ➕ Variant Output Support
- 🧹 One-click Clear Workspace
- 📱 Fully Responsive Design
- 🎨 Modern Purple Gradient UI
- ⚙️ Pure HTML, CSS & JavaScript

---

## 🛠️ Technologies Used

- HTML5
- CSS3
- JavaScript (ES6)

---

## 📂 Project Structure

```
Prompt-Testing-Sandbox/
│
├── index.html
├── README.md
└── assets/
```

---

## 🎯 How It Works

1. Enter a System Prompt.
2. (Optional) Add JSON variables for prompt injection.
3. Select an AI model.
4. Adjust Temperature and Max Tokens.
5. Enter a User Prompt.
6. Click **Run Test**.
7. View:
   - AI Response
   - Performance Metrics
   - Prompt History
8. Generate additional output variants if needed.

---

## ✨ Key Highlights

- Clean and intuitive UI
- Prompt engineering playground
- AI response simulation
- Prompt history management
- Configurable testing parameters
- Beginner-friendly interface
- Responsive across desktop, tablet, and mobile

---

## 📸 Preview

Add your project screenshots here.

```
assets/
 ├── screenshot-1.png
 ├── screenshot-2.png
 └── screenshot-3.png
```

---

## 👨‍💻 Engineers

**Mirza Yasir Abdullah Baig**  
AI Engineer | Prompt Engineer | Full Stack Developer

**Hamna Munir**  
AI Engineer | Frontend Developer | UI/UX Designer

---

## 🤝 Contributions

Contributions, feature suggestions, and improvements are welcome. Feel free to fork the repository and submit a pull request.

---

## 📄 License

This project is released for educational and learning purposes.

---

## ⭐ Support

If you found this project useful, consider giving it a ⭐ on GitHub.
